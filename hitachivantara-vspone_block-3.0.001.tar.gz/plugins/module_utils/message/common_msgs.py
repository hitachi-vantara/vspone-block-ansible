from enum import Enum


class CommonMessage(Enum):
    STORAGE_SYSTEM_INFO_MISSING = "missing required arguments: storage_system_info"
