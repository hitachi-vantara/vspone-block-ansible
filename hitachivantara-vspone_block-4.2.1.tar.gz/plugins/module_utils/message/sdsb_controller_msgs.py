from enum import Enum


class SDSBControllerValidationMsg(Enum):

    CONTROLLER_NOT_FOUND = "Could not find the storage controller with id {}."
