from enum import Enum


class VSPStotageSystemMonitorValidateMsg(Enum):
    ALERT_TYPE_NEEDED = "alert_type is required when query field is alerts."
