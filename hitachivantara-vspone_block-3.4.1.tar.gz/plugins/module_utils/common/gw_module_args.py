
# -*- coding: utf-8 -*-

class GatewayArgs:
    COMMON_ARGS = {
            "required": True,
            "type": "dict",
            "options": {
                "address": {
                    "required": True,
                    "type": "str",
                },
                "username": {
                    "required": False,
                    "type": "str",
                },
                "password": {
                    "required": False,
                    "no_log": True,
                    "type": "str",
                },
                "api_token": {
                    "required": False,
                    "type": "str",
                    "no_log": True,
                },
                "subscriber_id": {
                    "required": False,
                    "type": "str",
                },
                "connection_type": {
                    "required": False,
                    "type": "str",
                    "choices": ["gateway"],
                    "default": "gateway",
                },
            },
        }

    def get_subscriber_facts_args(self):
        self.COMMON_ARGS["options"].pop("subscriber_id", None)
        return {
            "connection_info": self.COMMON_ARGS,
            "spec": {
                "required": False,
                "type": "dict",
                "options": {
                    "subscriber_id": {
                        "required": False,
                        "type": "str",
                    },
                },
            },
        }
    

DEPCRECATED_MSG = ( "This module is deprecated and will be removed in a future release. Please use the alternative module")